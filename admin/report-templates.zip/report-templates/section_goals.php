<?php
/**
 * section_goals.php — Financial Goals Status
 *
 * For each goal:
 *   1. Current accumulated value vs target + accurate mPDF progress bar.
 *   2. Projection: corpus at 12% XIRR + remaining SIPs → projected value at goal date.
 *        FV = corpus × (1.12)^years  +  SIP × [((1+r)^n − 1)/r] × (1+r)
 *        r = monthly rate = (1.12)^(1/12) − 1,  n = months remaining
 *   3. Projected shortfall/surplus vs target.
 *   4. Progress bar uses linear-gradient in single TD (mPDF-safe).
 *
 * $goalsFundInfo keyed by goal name → array of fund rows:
 *   fund_name, investment_type, asset_class, current_value, profit_loss, xirr,
 *   goal_amount, goal_date, SIP_Info[]
 */

if (!function_exists('n')) { function n($v): float { return (float)str_replace(',', '', $v ?? 0); } }
if (empty($goalsFundInfo)) return;

// ── Projection at 12% XIRR ────────────────────────────────────────────────────
if (!function_exists('projectGoalValue')) {
    function projectGoalValue(float $corpus, float $monthlySip, int $n, float $rate = 0.12): float
    {
        if ($n <= 0) return $corpus;
        $r        = pow(1.0 + $rate, 1.0 / 12.0) - 1.0;
        $years    = $n / 12.0;
        $fvCorpus = $corpus * pow(1.0 + $rate, $years);
        $fvSip    = ($r > 0 && $monthlySip > 0)
            ? $monthlySip * ((pow(1.0 + $r, $n) - 1.0) / $r) * (1.0 + $r)
            : $monthlySip * $n;
        return $fvCorpus + $fvSip;
    }
}

// ── Calculate ADDITIONAL monthly SIP needed to reach target at given XIRR ──────
if (!function_exists('calculateAdditionalMonthlySipForTarget')) {
    function calculateAdditionalMonthlySipForTarget(float $target, float $currentCorpus, float $existingSip, int $months, float $rate = 0.12): float
    {
        if ($months <= 0) return 0.0;
        
        $projectedWithExisting = projectGoalValue($currentCorpus, $existingSip, $months, $rate);
        if ($projectedWithExisting >= $target) return 0.0;

        $additionalShortfall = $target - $projectedWithExisting;
        $r = pow(1.0 + $rate, 1.0 / 12.0) - 1.0;
        if ($r <= 0) return $additionalShortfall / $months;

        $annuityFactor = ((pow(1.0 + $r, $months) - 1.0) / $r) * (1.0 + $r);
        return $annuityFactor > 0 ? $additionalShortfall / $annuityFactor : 0.0;
    }
}

// ── mPDF-safe progress bar using table with pixel widths ───────────────────
if (!function_exists('goalProgressBar')) {
    function goalProgressBar(float $pct, string $color): string
    {
        $p = max(0.0, min(100.0, $pct));
        $filledWidth = round(2.5 * $p, 1); // 250px total width
        $emptyWidth = 250 - $filledWidth;
        $pctText = number_format($p, 1) . '%';

        $bar = '<table style="width:250px;border-collapse:collapse;">';
        $bar .= '<tr>';
        if ($filledWidth > 0) {
            $bar .= '<td style="width:'.$filledWidth.'px;height:14px;background-color:'.$color.';padding:0;border:0;"></td>';
        }
        if ($emptyWidth > 0) {
            $bar .= '<td style="width:'.$emptyWidth.'px;height:14px;background-color:#e0e8f4;padding:0;border:0;"></td>';
        }
        $bar .= '</tr></table>';

        return '<table style="border-collapse:collapse;"><tr>'
             . '<td style="padding:0;vertical-align:middle;">'.$bar.'</td>'
             . '<td style="padding:0 0 0 8px;vertical-align:middle;font-size:7.5pt;font-weight:bold;color:#333;">'.$pctText.'</td>'
             . '</tr></table>';
    }
}

$today = new DateTime();

// ── Calculate totals across all goals ──────────────────────────────────────
$totalGoalCount = 0;
$totalGoalTarget = 0.0;
$totalCollected = 0.0;
$totalExistingSip = 0.0;
$totalAdditionalSip = 0.0;
$totalShortfall = 0.0;
$goalSummaries = [];

foreach ($goalsFundInfo as $goalName => $fundList) {
    $totalGoalCount++;
    $goalTotal = 0.0; $goalTarget = 0.0;
    $goalDate = ''; $totalSip = 0.0;

    foreach ($fundList as $f) {
        $goalTotal += (float)($f['current_value'] ?? 0);
        if (!$goalTarget && !empty($f['goal_amount'])) $goalTarget = (float)$f['goal_amount'];
        if (!$goalDate && !empty($f['goal_date'])) $goalDate = $f['goal_date'];
        foreach ($f['SIP_Info'] ?? [] as $s) $totalSip += (float)($s['Amount'] ?? 0);
    }

    $shortfallNow = max(0.0, $goalTarget - $goalTotal);
    $pct = $goalTarget > 0 ? round($goalTotal / $goalTarget * 100, 1) : 0;
    $color = $pct >= 100 ? '#1a7a4a' : ($pct >= 60 ? '#2196f3' : ($pct >= 30 ? '#e67e22' : '#e74c3c'));

    $monthsLeft = 0;
    if ($goalDate) {
        try {
            $gdt = new DateTime($goalDate);
            $monthsLeft = max(0, (int)(($gdt->getTimestamp() - $today->getTimestamp()) / (86400 * 30.4375)));
        } catch (\Exception $e) {}
    }

    $projVal = ($goalTarget > 0 && $monthsLeft > 0) ? projectGoalValue($goalTotal, $totalSip, $monthsLeft, 0.12) : 0.0;
    $projPct = $goalTarget > 0 ? round($projVal / $goalTarget * 100, 1) : $pct;
    $additionalSip = ($goalTarget > 0 && $monthsLeft > 0) ? calculateAdditionalMonthlySipForTarget($goalTarget, $goalTotal, $totalSip, $monthsLeft, 0.12) : 0.0;

    $goalSummaries[] = [
        'name' => $goalName,
        'target' => $goalTarget,
        'collected' => $goalTotal,
        'sip' => $totalSip,
        'shortfall' => $shortfallNow,
        'extraSip' => $additionalSip,
        'color' => $color,
        'pct' => $pct,
        'projectedPct' => $projPct,
    ];

    $totalGoalTarget += $goalTarget;
    $totalCollected += $goalTotal;
    $totalExistingSip += $totalSip;
    $totalAdditionalSip += $additionalSip;
    $totalShortfall += $shortfallNow;
}

usort($goalSummaries, static function ($a, $b) {
    return $b['shortfall'] <=> $a['shortfall'];
});

$overallPct = $totalGoalTarget > 0 ? round($totalCollected / $totalGoalTarget * 100, 1) : 0;
?>

<div class="section-header">Financial Goals — Status</div>

<!-- ── Goals Summary Tables ──────────────────────────────────────────────────── -->
<table style="width:100%;border-collapse:collapse;font-size:8pt;margin-bottom:10px;">
    <tr>
        <td style="padding:8px;border:0.5pt solid #d7e0ed;background:#f7fbff;width:20%;font-weight:bold;">Total goals</td>
        <td style="padding:8px;border:0.5pt solid #d7e0ed;background:#f7fbff;width:20%;font-weight:bold;">Target amount</td>
        <td style="padding:8px;border:0.5pt solid #d7e0ed;background:#f7fbff;width:20%;font-weight:bold;">Accumulated</td>
        <td style="padding:8px;border:0.5pt solid #d7e0ed;background:#f7fbff;width:20%;font-weight:bold;">Shortfall</td>
        <td style="padding:8px;border:0.5pt solid #d7e0ed;background:#f7fbff;width:20%;font-weight:bold;">Extra SIP</td>
    </tr>
    <tr>
        <td style="padding:8px;border:0.5pt solid #d7e0ed;"><?= $totalGoalCount ?></td>
        <td style="padding:8px;border:0.5pt solid #d7e0ed;"><?= number_format($totalGoalTarget, 0) ?></td>
        <td style="padding:8px;border:0.5pt solid #d7e0ed;"><?= number_format($totalCollected, 0) ?> <span style="color:#666;">(<?= $overallPct ?>%)</span></td>
        <td style="padding:8px;border:0.5pt solid #d7e0ed;"><?= number_format($totalShortfall, 0) ?></td>
        <td style="padding:8px;border:0.5pt solid #d7e0ed;"><?= number_format($totalAdditionalSip, 0) ?>/month</td>
    </tr>
</table>

<!-- ── Individual Goal Summary ──────────────────────────────────────────────────── -->
<table style="width:100%;border-collapse:collapse;font-size:8pt;margin-bottom:12px;">
    <thead>
        <tr style="background:#f1f7ff;border-bottom:0.5pt solid #d7e0ed;">
            <th style="width:30%;padding:6px;text-align:left;">Goal</th>
            <th style="width:30%;padding:6px;text-align:left;">Progress</th>
            <th style="width:15%;padding:6px;text-align:right;">Shortfall</th>
            <th style="width:15%;padding:6px;text-align:right;">Extra SIP/mo</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($goalSummaries as $goal): ?>
            <tr style="border-top:0.3pt solid #e1e8f2;">
                <td style="padding:6px;vertical-align:top;">
                    <strong><?= htmlspecialchars($goal['name']) ?></strong><br>
                    <span style="color:#666;font-size:7pt;"><?= number_format($goal['collected'], 0) ?> / <?= number_format($goal['target'], 0) ?></span>
                </td>
                <td style="padding:6px;vertical-align:middle;font-size:7.5pt;">
                    <?php
                        $p = max(0.0, min(100.0, $goal['pct']));
                        $bar = '<table style="width:120px;border-collapse:collapse;height:12px;"><tr>';
                        $bar .= '<td style="width:'.$p.'%;background:'.$goal['color'].';padding:0;border:0;"></td>';
                        $bar .= '<td style="width:'.(100-$p).'%;background:#e8eff7;padding:0;border:0;"></td></tr></table>';
                        echo '<div style="display:flex;align-items:center;gap:8px;">' . $bar . '<span style="font-weight:bold;">'.number_format($p,1).'%</span></div>';
                    ?>
                </td>
                <td style="padding:6px;text-align:right;vertical-align:middle;color:#c0392b;font-weight:bold;"><?= $goal['shortfall'] > 0 ? number_format($goal['shortfall'], 0) : '—' ?></td>
                <td style="padding:6px;text-align:right;vertical-align:middle;font-weight:bold;background:#ffeaa7;padding:4px 6px;border-radius:2px;"><?= number_format($goal['extraSip'], 0) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<div style="font-size:7.5pt;color:#555;line-height:1.4;margin-bottom:12px;padding:6px;background:#f9fafb;border-left:2px solid #2196f3;">
    Forecast assumes 12% p.a. growth on SIPs and current corpus. Extra SIP is the estimated monthly top-up required to meet the goal by its target date.
</div>

<!-- ── Individual Goal Details ──────────────────────────────────────────────────── -->

<?php
$goalCounter = 0;
foreach ($goalsFundInfo as $goalName => $fundList):
    $goalCounter++;
    $goalTotal  = 0.0; $goalTarget = 0.0;
    $goalDate   = '';  $totalSip   = 0.0;

    foreach ($fundList as $f) {
        $goalTotal += (float)($f['current_value'] ?? 0);
        if (!$goalTarget && !empty($f['goal_amount'])) $goalTarget = (float)$f['goal_amount'];
        if (!$goalDate  && !empty($f['goal_date']))    $goalDate   = $f['goal_date'];
        foreach ($f['SIP_Info'] ?? [] as $s) $totalSip += (float)($s['Amount'] ?? 0);
    }

    // Months remaining
    $monthsLeft = 0;
    if ($goalDate) {
        try {
            $gdt = new DateTime($goalDate);
            $monthsLeft = max(0, (int)(($gdt->getTimestamp() - $today->getTimestamp()) / (86400 * 30.4375)));
        } catch (\Exception $e) {}
    }

    // Current status
    $achievedPct  = ($goalTarget > 0) ? min(round($goalTotal / $goalTarget * 100, 1), 100) : 0;
    $shortfallNow = max(0.0, $goalTarget - $goalTotal);
    $barColor     = $achievedPct >= 100 ? '#1a7a4a' : ($achievedPct >= 60 ? '#2196f3' : ($achievedPct >= 30 ? '#e67e22' : '#e74c3c'));

    // Projection
    $hasProj  = ($goalTarget > 0 && $monthsLeft > 0);
    $projVal  = $hasProj ? projectGoalValue($goalTotal, $totalSip, $monthsLeft, 0.12) : 0.0;
    $projShort = max(0.0, $goalTarget - $projVal);
    $projSurp  = max(0.0, $projVal - $goalTarget);
    $additionalMonthlySipNeeded = $hasProj ? calculateAdditionalMonthlySipForTarget($goalTarget, $goalTotal, $totalSip, $monthsLeft, 0.12) : 0.0;
?>

<table style="margin-top:10px;border:0.5pt solid #b0c4de;border-collapse:collapse;width:100%;">

    <!-- Title row -->
    <tr style="background:#e8f0fa;">
        <td colspan="2" style="padding:5px 8px;font-weight:bold;font-size:9pt;width:55%;">
            Funds allocated for Goal <?= $goalCounter ?>: <?= htmlspecialchars($goalName) ?>
        </td>
        <td colspan="2" style="padding:5px 8px;font-size:8pt;text-align:right;width:45%;">
            Target: <strong><?= number_format($goalTarget, 0) ?></strong>
            <?php if ($goalDate): ?>
                &nbsp;&bull;&nbsp;By <strong><?= htmlspecialchars($goalDate) ?></strong>
                <?php if ($monthsLeft > 0): ?>
                    &nbsp;<span style="color:#666;">(<?= $monthsLeft ?> months remaining)</span>
                <?php endif; ?>
            <?php endif; ?>
        </td>
    </tr>

    <!-- Current status + progress bar -->
    <tr>
        <td style="padding:4px 8px;font-size:8pt;width:30%;vertical-align:middle;">
            Accumulated:
            <strong style="color:<?= $barColor ?>;"><?= number_format($goalTotal, 0) ?></strong>
            &nbsp;<span style="color:#666;">(<?= $achievedPct ?>%)</span>
        </td>
        <td style="padding:4px 8px;font-size:8pt;width:25%;vertical-align:middle;">
            <?php if ($shortfallNow > 0): ?>
                Current gap: <strong style="color:#c0392b;"><?= number_format($shortfallNow, 0) ?></strong>
            <?php else: ?>
                <strong style="color:#1a7a4a;">&#x2713; Target reached</strong>
            <?php endif; ?>
        </td>
        <td colspan="2" style="padding:4px 12px;width:45%;vertical-align:middle;">
            <?= goalProgressBar((float)$achievedPct, $barColor) ?>
        </td>
    </tr>

    

</table>

<!-- Fund list -->
<table style="margin-top:2px;">
    <thead>
        <tr>
            <th style="width:30%">Fund Name</th>
            <th style="width:7%">Type</th>
            <th style="width:8%">Asset</th>
            <th class="text-right" style="width:12%">Curr Value</th>
            <th class="text-right" style="width:11%">P&amp;L</th>
            <th class="text-right" style="width:6%">XIRR %</th>
            <th class="text-right" style="width:11%">SIP/month</th>
            <th style="width:7%">Mode</th>
            <th class="text-right" style="width:6%">Alloc%</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($fundList as $f):
        $xirr    = $f['xirr'] ?? '';
        $xirrNum = (float)str_replace(',', '', $xirr);
        $pl      = (float)($f['profit_loss'] ?? 0);
        $cv      = (float)($f['current_value'] ?? 0);
        $allocPct = $goalTotal > 0 ? round($cv / $goalTotal * 100, 1) : 0;
        $sipAmt  = 0; $sipMode = '—';
        foreach ($f['SIP_Info'] ?? [] as $s) {
            $sipAmt += (float)($s['Amount'] ?? 0);
            if ($sipMode === '—') $sipMode = $s['Sip_Type'] ?? 'SIP';
        }
    ?>
        <tr>
            <td><?= htmlspecialchars(cleanFundName($f['fund_name'] ?? '')) ?></td>
            <td class="text-center"><?= strtoupper($f['investment_type'] ?? '') ?></td>
            <td class="text-center"><?= strtoupper($f['asset_class'] ?? '') ?></td>
            <td class="text-right"><?= number_format($cv, 0) ?></td>
            <td class="text-right <?= $pl >= 0 ? 'positive' : 'negative' ?>"><?= ($pl >= 0 ? '+' : '') . number_format($pl, 0) ?></td>
            <td class="text-right <?= $xirrNum >= 0 ? 'positive' : 'negative' ?>">
                <?= is_numeric(str_replace(',', '', $xirr)) ? number_format($xirrNum, 2).'%' : '—' ?>
            </td>
            <td class="text-right"><?= $sipAmt > 0 ? ''.number_format($sipAmt, 0) : '<span style="color:#aaa;">—</span>' ?></td>
            <td class="text-center"><?= htmlspecialchars($sipMode) ?></td>
            <td class="text-right" style="color:#666;"><?= $allocPct ?>%</td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot>
        <tr class="total-row">
            <td colspan="3"><strong>Goal Total</strong></td>
            <td class="text-right"><strong><?= number_format($goalTotal, 0) ?></strong></td>
            <td colspan="3"></td>
            <td colspan="2" class="text-right" style="color:#555;">
                <strong><?= $totalSip > 0 ? number_format($totalSip, 0) : '—' ?>/mo</strong>
            </td>
        </tr>
    </tfoot>
</table>

<?php endforeach; ?>

<p style="font-size:6.5pt;color:#888;margin-top:6px;line-height:1.5;">
    * Projection assumes current SIP continues monthly for the remaining duration and earns 12% XIRR p.a.
    Formula: Projected = Corpus &times; (1.12)<sup>years</sup>
    + SIP &times; [((1+r)<sup>n</sup>&minus;1) / r] &times; (1+r),
    where r = monthly equivalent of 12% p.a., n = months remaining.
    Illustrative only — actual returns may differ.
</p>
