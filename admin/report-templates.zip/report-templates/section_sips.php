<?php
/**
 * section_sips.php — Active SIPs
 */
if (empty($runningSIPInfo)) return;
?>

<div class="sub-header mt-8" style="margin-top:15px;">Active Systematic Investment Plans (SIPs)</div>

<table>
    <thead>
        <tr>
            <th style="width:30%">Fund Name</th>
            <th class="text-right" style="width:12%">SIP Amt (₹)</th>
            <th class="text-center" style="width:12%">Frequency</th>
            <th class="text-center" style="width:12%">Start Date</th>
            <th class="text-center" style="width:12%">End Date</th>
            <th class="text-right" style="width:11%">Units Held</th>
            <th class="text-right" style="width:11%">Curr. Value</th>
			<th class="text-right" style="width:11%">XIRR %</th>

        </tr>
    </thead>
    <tbody>
    <?php
    $totalSipAmount = 0;
    $totalSipCurrentValue = 0;
    foreach ($runningSIPInfo as $sip):
        $amount = (float)str_replace(',', '', $sip['Amount'] ?? 0);
        $totalSipAmount += $amount;
        $currentValue = (float)($sip['current_value'] ?? 0);
        $totalSipCurrentValue += $currentValue;
    ?>
        <tr>
            <td><?= htmlspecialchars(cleanFundName($sip['Fund_Name'] ?? '')) ?></td>
            <td class="text-right"><?= number_format($amount, 0) ?></td>
            <td class="text-center"><?= htmlspecialchars($sip['Frequency'] ?? '') ?></td>
            <td class="text-center"><?= !empty($sip['From_Date']) && $sip['From_Date'] != '0000-00-00' ? date('d-M-Y', strtotime($sip['From_Date'])) : '—' ?></td>
            <td class="text-center"><?= !empty($sip['To_Date']) && $sip['To_Date'] != '0000-00-00' && $sip['To_Date'] != '2099-12-31' && $sip['To_Date'] != '2999-12-31' ? date('d-M-Y', strtotime($sip['To_Date'])) : 'Until Cancelled' ?></td>
            <td class="text-right"><?= number_format($sip['units'] ?? 0, 3) ?></td>
            <td class="text-right"><?= number_format($currentValue, 0) ?></td>
			<td><?= isset($sip['xirr']) ? number_format($sip['xirr'], 2) . '%' : '—' ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot>
        <tr class="total-row">
            <td><strong>Total Active SIPs (<?= count($runningSIPInfo) ?>)</strong></td>
            <td class="text-right"><strong><?= number_format($totalSipAmount, 0) ?></strong></td>
            <td colspan="4"></td>
            <td class="text-right"><strong><?= number_format($totalSipCurrentValue, 0) ?></strong></td>
            <td class="text-right"><strong><?= isset($sipXirrResult['portfolio_xirr']) ? number_format($sipXirrResult['portfolio_xirr'], 2) . '%' : '—' ?></strong></td>
        </tr>
    </tfoot>
</table>

<?php if (!empty($sipXirrResult) && !empty($sipChartPng) && !empty($sipValChartPng)): 
    $sXirr = $sipXirrResult['portfolio_xirr'] ?? 0;
    $bXirr = $sipXirrResult['benchmark_xirr'] ?? 0;
    $alpha = $sXirr - $bXirr;
    $alphaStr = 'Alpha: ' . ($alpha >= 0 ? '+' : '') . number_format($alpha, 2) . '%';
    $alphaColor = $alpha >= 0 ? '#1a7a4a' : '#c0392b';
?>
<div class="sub-header mt-8" style="margin-top:15px;">Active SIPs — Performance Analysis</div>
<table style="width:100%;margin-top:15px;border-collapse:separate;border-spacing:8px 0;">
    <tr>
        <td style="width:50%;vertical-align:top;text-align:center;border:0.5pt solid #BDC9D5;background:#F7FAFD;padding:8px;">
            <div style="font-size:10pt;font-weight:bold;color:#1D3557;margin-bottom:4px;">
                XIRR - SIP <small style="color: #777; font-size: 80%;">(All Active SIPs)</small>
            </div>
            <img src="<?= BenchmarkXirr::pngToDataUri($sipChartPng) ?>" style="width:100%;max-width:340px;"/>
            <div style="font-size:10pt;font-weight:bold;color:<?= $alphaColor ?>;margin-top:3px;">
                <?= $alphaStr ?>
            </div>
			<!--
            <div style="font-size:7pt;color:#444;margin-top:3px;line-height:1.8;">
                <span style="display:inline-block;width:20px;height:3px;background:#1E3A5F;vertical-align:middle;margin-right:3px;"></span><strong>Portfolio</strong>
                &nbsp;&nbsp;
                <span style="display:inline-block;width:20px;height:3px;background:#E87722;vertical-align:middle;margin-right:3px;"></span><strong>Nifty 500 Mirror</strong>
            </div>
			-->
        </td>
        <td style="width:50%;vertical-align:top;text-align:center;border:0.5pt solid #BDC9D5;background:#F7FAFD;padding:8px;">
            <div style="font-size:10pt;font-weight:bold;color:#1D3557;margin-bottom:4px;">
                Current Value (₹)
            </div>
            <img src="<?= BenchmarkXirr::pngToDataUri($sipValChartPng) ?>" style="width:100%;max-width:340px;"/>
            <div style="font-size:9pt;font-weight:bold;color:transparent;margin-top:3px;">-</div>
		<!--
		  <div style="font-size:7pt;color:#444;margin-top:3px;line-height:1.8;">
                <span style="display:inline-block;width:20px;height:3px;background:#1E3A5F;vertical-align:middle;margin-right:3px;"></span><strong>Portfolio</strong>
                &nbsp;&nbsp;
                <span style="display:inline-block;width:20px;height:3px;background:#E87722;vertical-align:middle;margin-right:3px;"></span><strong>Nifty 500 Mirror</strong>
            </div>
		-->	
        </td>
    </tr>
</table>
<?php endif; ?>